/*
By Fianz
*/

const settings = {
  token: '7490842737:AAEzsJpJILq2KKtKu7hO94KKmnFE0RtZUUY',
  adminId: '7089735468', 
  pp: 'https://files.catbox.moe/ilfpbf.jpg',
urladmin: 'https://t.me/LaxzyCrasher',
  pp: 'https://files.catbox.moe/ilfpbf.jpg',
    //SERVER 1
  domain: 'https://rayzuhost.duckdns.org', // domain
  plta: 'ptla_aQT6whDscOTnGkCaBqWYySpdmvv63t3ToQSjVTUCGqS', //  plta yang sesuai
  pltc: 'ptlc_jVbiaspueDjRl0EiTUnHa0Fml3jFsMU2xA3WK43A68m', // pltc yang sesuai
  
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;