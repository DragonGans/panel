//SC RENAME BY DINZID VyL
// © RENAME BY DinzID Vyl 2022 - 2025
// © DanzNano
//JANGAN HAPUS CREDITS!! HAPUS? = GW ENC SEMUA!! 

# YOIMIYA - MD // DINZID VyL  
Yoimiya - mD adalah bot WhatsApp berbasis **Baileys** yang memiliki berbagai fitur keren buat memudahkan hidup lo!  

## Fitur Utama  

✅ **𝙂𝙍𝙊𝙐𝙋 𝙈𝙀𝙉𝙐** (Welcome, Anti-link, Auto Close Group)  
✅ **𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿 𝙈𝙀𝙉𝙐** (YouTube, TikTok DLL)  
✅ **𝙎𝙏𝙄𝘾𝙆𝙀𝙍 & 𝙈𝙀𝘿𝙄𝘼** (Convert ke stiker, brat image/video)  
✅ **𝙁𝙐𝙉 𝙈𝙀𝙉𝙐 & 𝙍𝙋𝙂** (KERJA, CRAFT, BANKCEK DLL)  
✅ **𝙄𝙎𝙇𝘼𝙈𝙄 𝙈𝙀𝙉𝙐** (PENGINGAT ADZAN, PENGINGAT SHOLAT, AUTO ADZAN DLL)


#WAJIB 𝐁𝐀𝐂𝐀 !!
Edit file `settings.js` sebelum menjalankan bot:  

## 𝙂𝘼𝘽𝙐𝙉𝙂 𝙆𝙊𝙈𝙐𝙉𝙄𝙏𝘼𝙎 𝘿𝙄𝙉𝙕𝙄𝘿 𝘾𝙃𝙓

🔹 **𝙂𝙍𝙊𝙐𝙋 𝘾𝙃𝘼𝙏** https://chat.whatsapp.com/BXmn4vEG1cXEwLPduxEPXz

🔹 **𝘾𝙃𝘼𝙉𝙉𝙀𝙇 𝙊𝙍𝙄 𝙔𝙊𝙄𝙈𝙄𝙔𝘼** https://whatsapp.com/channel/0029VbAuu0fFHWpvAZAS3d17  

#DILARANG HAPUS CREDITS 



CARA PASANG SC DI PANEL

1. BUKA PANEL KALIAN
2. PERGI KE FILES DI PANEL KALIAN
3. PILIH YANG [ UPLOAD ]
4. CARI SC NYA, LALU PILIH SC YANG MAU DI UPLOAD
5. PILIH TITIK 3 DI SEBELAH KANAN SC NYA 
CONTOH NO 5 ->  [   yoimiyaMD.zip              ...      ] 
6. pencet titik 3 nya 
7. pilih yang unarzhip
8. ke menu console 
9. tinggal start 
10. tunggu sampai disuruh masukkin kode
11. masukkin kode dengan awalan 62
contoh -> [ 62838123456789 ] 


TERIMA KASIH SUDAH SUPPORT SEJAUH INI 



TQTO
1.DanzNano
2.DinzID
3.Ditss
4.rizall
5.FlowFalcon Learn Coding

PENYEDIA API
Siputzx Api
Shanz
Skyzo

BASE
Xeon

#footer '© DinzID VyL | Yoimiya - MD'